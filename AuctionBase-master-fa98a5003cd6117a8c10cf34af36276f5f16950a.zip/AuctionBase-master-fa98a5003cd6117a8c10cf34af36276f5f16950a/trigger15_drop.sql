PRAGMA foreign_keys = ON;
drop TRIGGER check_bid_time;
