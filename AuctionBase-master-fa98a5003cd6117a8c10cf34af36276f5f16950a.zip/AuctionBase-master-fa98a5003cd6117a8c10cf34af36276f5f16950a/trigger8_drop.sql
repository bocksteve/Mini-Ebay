PRAGMA foreign_keys = ON;
drop TRIGGER update_highest_price;
