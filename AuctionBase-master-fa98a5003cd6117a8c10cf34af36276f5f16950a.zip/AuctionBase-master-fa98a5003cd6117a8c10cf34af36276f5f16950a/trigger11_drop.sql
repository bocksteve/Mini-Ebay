PRAGMA foreign_keys = ON;
drop TRIGGER stop_early_late_bids;
