PRAGMA foreign_keys = ON;
drop TRIGGER actual_bids;
