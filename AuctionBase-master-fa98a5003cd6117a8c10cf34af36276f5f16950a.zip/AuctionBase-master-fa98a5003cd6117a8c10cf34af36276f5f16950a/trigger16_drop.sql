PRAGMA foreign_keys = ON;
drop TRIGGER advance_current_time;
