PRAGMA foreign_keys = ON;
drop TRIGGER check_duplicate_bid;
