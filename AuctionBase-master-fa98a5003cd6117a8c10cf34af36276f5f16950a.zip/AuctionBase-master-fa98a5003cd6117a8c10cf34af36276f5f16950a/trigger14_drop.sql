PRAGMA foreign_keys = ON;
drop TRIGGER check_lower_bid;
