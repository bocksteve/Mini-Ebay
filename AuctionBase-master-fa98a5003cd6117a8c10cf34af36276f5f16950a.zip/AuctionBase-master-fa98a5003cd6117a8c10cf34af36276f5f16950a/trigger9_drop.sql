PRAGMA foreign_keys = ON;
drop TRIGGER bidSell;
